﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WineTasting.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
